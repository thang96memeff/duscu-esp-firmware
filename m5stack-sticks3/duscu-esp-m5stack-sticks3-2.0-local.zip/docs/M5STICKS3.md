# M5StickS3 N8R8

Profile ESP-IDF: `m5stack-sticks3`, flash 8 MB QIO/80 MHz, PSRAM Octal 8 MB/80 MHz, CPU 240 MHz. Màn ST7789P3 135×240, giao diện mặc định ngang 240×135, rotation 3, offset vật lý 52/40. Settings → Display cho phép xoay và đổi cấu hình màn.

| Thành phần | Chân / cấu hình |
| --- | --- |
| ST7789 | MOSI39, SCK40, CS41, DC45, RST21, BL38, SPI2 20 MHz |
| M5PM1 | I2C SDA47/SCL48, địa chỉ 0x6E |
| Nút A / B | GPIO11 / GPIO12 |
| IR | TX46 / RX42; nhận bằng RMT DMA |
| SPI ngoài | MOSI6 / MISO4 / SCK5; SPI3 |
| SD / CC1101 / nRF24 | CS7 / CS2-GDO0:3 / CS8-CE1 |
| BW16 | UART TX43/RX44, 115200 |
| USB | D-19 / D+20; console USB Serial/JTAG, chuyển sang MSC khi bật USB mass storage |
| Grove | SDA9/SCL10 |

## Đối chiếu profile mod — 18/11/2026

Đã đối chiếu 49 macro phần cứng trong `boards/m5stack-sticks3/m5stack-sticks3.ini` của bản mod, cùng `interface.cpp` và board JSON. Bản vá trong INI đã comment `USE_M5GFX`, chọn `ST7789_DRIVER`, SPI 20 MHz. DUSCU giữ kết quả tương đương bằng driver **ESP-IDF trực tiếp**, không thêm M5GFX, M5Unified hoặc TFT_eSPI. Không đưa các hằng chân StickC đời cũ trong `pins_arduino.h` sang profile S3: chúng không trùng các macro đang được build trong INI.

Âm thanh: ES8311 I2C0x18, MCLK18/BCLK17/WS15/DOUT14, microphone DIN16; amplifier được điều khiển qua M5PM1. Khi dừng phát, tắt amplifier trước rồi đưa codec về standby. Khi boot, CS của SD/CC1101/nRF24 giữ cao, nRF CE giữ thấp, IR46 và Grove RF433 TX9 giữ thấp. Chân cấu hình `-1` không bị gọi GPIO output. Giữ cơ chế loại trừ IR/loa và chỉ tắt boost do chính driver bật, không đưa 5V ngược vào nguồn ngoài.

Các ánh xạ mở rộng trong profile tham chiếu: UART TX43/RX44; GPS TX9/RX10; PN532 SPI CS43; Grove SDA9/SCL10 cho thiết bị I2C ngoài; RF433 một chân TX9/RX10. Đây là **ánh xạ đầu nối**, không có nghĩa DUSCU đã có app GPS/PN532/FM/microphone. W5500 CS/INT và LoRa CS/RST/DIO0 trong INI đang là `-1`: không tự chọn chân hoặc bật các module chưa được nối. Chân âm thanh/microphone và I2C nội bộ được bảo vệ khỏi cấu hình trùng.

Chi tiết hash file tham chiếu và phạm vi: `docs/development/m5sticks3-board-review.json`. Test host chạy driver PM1 thật với I2C/GPIO giả lập để kiểm tra nguồn, pin, codec, IR refcount, sleep/shutdown; không thay cho kiểm tra điện trên thiết bị.

A: chọn; giữ 500 ms: quay lại. B: một lần đi tiếp, hai lần quay trước, giữ 500 ms quay lại. A+B: thao tác phụ trong game; giữ A+B khi khởi động khôi phục cấu hình màn/nút. Một lần B chờ khoảng 250 ms để phân biệt nhấn đôi.

Driver M5PM1 bật nguồn LCD, đọc điện áp pin và trạng thái sạc, tắt amplifier khi dùng IR, điều khiển boost 5 V theo nguồn ngoài và tắt boost sau khi dùng. Settings → Power có tắt nguồn M5PM1. Settings → Thông tin máy có thanh flash/SD/RAM/PSRAM và bảng chân module ngoài. Cấu hình có chân microphone/IMU để dành cho module sau; chưa có app ghi âm/IMU.

Files mở `.mp3` trên SD/SPIFFS bằng minimp3, stream theo khối 4KiB, phát I2S16bit vào ES8311/loa tích hợp. A play/pause; B tăng âm lượng5%, nhấn đôi B giảm5%; A+B đổi hai nút sang tua ±10s, A+B lần nữa trở về âm lượng; Back dừng và trả lại danh sách. Thời lượng và tua ước lượng theo bitrate với file VBR; thời gian đã phát tính từ số mẫu PCM thực tế. IR và loa loại trừ nhau khi dùng bộ thu IR tích hợp. Khi dừng phát, worker giải phóng cả decoder và stack32KiB.

```sh
pio run -e m5stack-sticks3 -j 2
python tools/package_firmware.py m5stack-sticks3
python tools/export_firmware.py m5stack-sticks3
```

Merged: `dist/m5stack-sticks3/duscu-m5stack-sticks3-merged.bin`, nạp tại `0x0`. Split: bootloader tại `0x0`, partitions tại `0x8000`, firmware tại `0x10000`. Không dùng BIN Xingzhi cho board này.

Đã kiểm tra build và mô hình pin/PMIC/nút trên máy phát triển; chưa có thiết bị thật để kiểm tra màn, nguồn IR, USB MSC hoặc ngoại vi. Sơ đồ dựa trên profile mod của chủ dự án và [tài liệu StickS3 chính thức](https://docs.m5stack.com/en/core/StickS3), [datasheet M5PM1](https://m5stack-doc.oss-cn-shenzhen.aliyuncs.com/1207/M5PM1_Datasheet_EN.pdf).

## Phạm vi bản build M5 ngày 18/11/2026

Bản thử M5 này được build từ snapshot riêng, giữ Portal Update trước các thay đổi đang được sửa đồng thời. Không ghi đè hoặc hoàn tác Portal/WiFi trong cây nguồn đang làm việc. Cấu hình và driver phần cứng M5 trong snapshot trùng bản vá ở cây nguồn chính. Xem `BUILD-SNAPSHOT.json` cạnh BIN và `docs/development/m5sticks3-build-20261118.json` để biết hash/phạm vi; mã nguồn build riêng được giữ trong backup nội bộ. Không coi BIN này là bản build của các thay đổi Portal đang dở.
