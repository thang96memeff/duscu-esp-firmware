# Boot image

`duscu-esp-boot.jpg` is the image supplied by the device owner for the boot screen.
Keep the editable source here; `dist/` is generated firmware output.

Original JPEG:126×128 pixels,7,279 bytes. It is embedded unchanged and decoded
once using the existing device ROM JPEG decoder. Raw RGB565 would take32,256
bytes before headers. A larger screen uses bilinear scaling; smaller screens
scale down. Both preserve aspect ratio and center the image with black margins.
OLED builds dither to1bit. Runtime image memory is released after startup.

To replace: use a baseline JPEG with this filename (not progressive/CMYK).
Changing the asset requires a later firmware build. No filesystem or SD card is
needed to display the embedded image.
