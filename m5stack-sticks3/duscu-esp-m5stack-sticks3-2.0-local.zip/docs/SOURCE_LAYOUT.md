# Cấu trúc mã nguồn

`src/` chỉ giữ entry point và khai báo component ESP-IDF:

```text
src/
├── main.cpp                 # Khởi động, vòng lặp, chế độ nguồn
├── CMakeLists.txt           # Danh sách source theo nhóm
├── idf_component.yml        # Dependency ESP-IDF
├── core/                    # Model, registry app, services, cấu hình, tài nguyên máy
├── hal/                     # Board, màn hình, pin, nút và touch
│   ├── bus/                 # SPI dùng chung
│   ├── boards/              # Nguồn/PMIC và tài nguyên theo board
│   └── radio/               # Driver CC1101/nRF, xử lý xung
├── ui/                      # Shell, layout, editor, theme, asset cache và icon
│   └── generated/           # Font/bitmap do tools sinh; không sửa tay
└── modules/
    ├── audio/               # MP3 stream, metadata và player nền
    ├── wifi/                # Quét/monitor/PCAP/TCP/AP
    ├── ble/                 # Payload và advertising state machine
    ├── radio/               # Màn RF/nRF và các công cụ đo
    ├── ir/                  # TV power worker
    │   └── generated/       # Dữ liệu TV CC0 đã pin
    ├── bw16/                # Giao thức UART companion
    ├── naoya/               # AI client HTTPS
    ├── files/               # File manager, viewer, SD, WebUI, USB MSC
    ├── settings/            # Màn cài đặt
    └── games/               # Tetris được chủ dự án cho phép port, Reef Dash
```

Ở cấp dự án: `assets/` giữ SVG chỉnh sửa; `third_party/` giữ mã/dữ liệu upstream và provenance; `licenses/` giữ license; `tools/` giữ generator/build/package; `tests/` giữ kiểm tra; `preview/` giữ bản UI offline; `boards/` và các sdkconfig/partition ở cấp dự án phục vụ PlatformIO. `docs/development/` chứa ghi chú tiếp tục công việc.

Include nội bộ ghi đường dẫn từ gốc `src/`, ví dụ `#include "core/services.h"`, `#include "hal/display.h"`. Không thêm hàng loạt include-directory theo từng module và không tạo header chuyển tiếp tại đường dẫn cũ.

Muốn thêm chức năng: đặt source vào module tương ứng, thêm vào nhóm trong `src/CMakeLists.txt`, khai báo descriptor tại `src/core/apps.h`, đăng ký AppModule trong `src/ui/interface.h`. Xem `EXTENDING.md`. Nếu sửa icon/font, chạy generator trong `tools/`; các output đã được trỏ tới thư mục `generated/` mới.

`source-layout.json` ghi ánh xạ đường dẫn trước/sau. Việc tổ chức thư mục không nhập mã Bruce và không thay đổi giấy phép thành phần.
