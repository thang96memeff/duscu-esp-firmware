# Orbit Main Menu

- Left: upright1bit icons travel along a right-facing half-circle; active icon grows into a fixed double-outline focus frame.
- Right: active name in a shallow-rounded rectangular frame. Neighbor names are smaller and dimmer; position,size and opacity interpolate together.
- Battery percentage/icon at top right. Invalid reading stays `--%`; charging uses existing real status. `DUSCU-IDF:1.0` at bottom right.
- Main-menu motion240ms, existing16ms animation render budget. Interrupting a move starts at its current interpolated position. Wrap,visible-app masks,custom icons,wave frames,theme/wallpaper and animations-off remain supported. No new RGB framebuffer. Hardware FPS is not measured.
- `min(width,height)<135`: show only active icon/name when settled. Old/new active items slide through the clipped viewport during a transition.135px inclusive and larger show neighbors. Rotation uses current screen dimensions.
- Touch: active icon or name selects; top/bottom rows navigate; status/footer touches do not launch an app. Physical-button app selection logic is unchanged.
- Outer border inset1px,radius4px; main icon frame radius5px/two strokes; name frame radius3px. Compact home also retains a border.

## Fonts

Native Unifont12/16/20/28 data is taken from the owner mod's `src/core` font resources only. Generated normal UI family is renamed Duscu Mono. The independent exporter does not depend on Arduino,TFT_eSPI or copied rendering functions. Font input hashes,source hex and upstream shape verification are in `third_party/font/mod/provenance.json`; license/copyright in `licenses/OFL-Unifont.txt`. Regenerate with `python tools/import_mod_fonts.py`; check with `--check`. `tools/make_ui_font.py` forwards to the active exporter and cannot silently restore Noto. Boot5x8 is unchanged; compact normal text uses the same5x8 compositor. Normal submenu/body text uses the new native family.

## Validation and scope

Only UI/display/font source changed; core and module logic,including owner WiFi/BLE/GIF/RF/IR/nRF implementations,remain unchanged. Existing submenu animation is unchanged. ASan/UBSan tests cover orbit geometry,retargeting,wrapping,contrast,clipping,TFT/OLED,10screen geometries,actual home/text methods,all11apps,2languages and5x8 metrics.23Python tests pass; existing graphics,input and icon regressions pass.

No browser preview,flash or hardware FPS test is performed by this UI change. Actual firmware build/export status is recorded in docs/development/CHECKPOINT.md and verification-latest.json.
