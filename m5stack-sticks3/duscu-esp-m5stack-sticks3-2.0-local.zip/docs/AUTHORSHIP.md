# Mã trong bản Bruce mod có phải của bạn không?

Nếu bạn tự viết phần mã có tính sáng tạo, quyền đối với phần đóng góp đó thường
vẫn thuộc bạn, trừ khi đã chuyển giao quyền hoặc có thỏa thuận khác. AGPL không
bắt bạn chuyển quyền sở hữu cho tác giả Bruce. Tuy nhiên:

- Phần mã Bruce và phần của người khác vẫn thuộc chủ sở hữu tương ứng.
- Sửa một hàm của Bruce không biến toàn bộ hàm đó thành mã riêng của bạn.
- Nếu phát hành bản kết hợp thuộc AGPL, phải tuân thủ AGPL cho bản kết hợp, kể cả
  khi một số phần đóng góp là do bạn viết.
- Phần bạn thực sự sở hữu có thể dùng lại/cấp phép khác trong một sản phẩm khác,
  miễn không đem theo phần biểu đạt được bảo hộ của người khác mà thiếu quyền.
- Không cần đóng góp ngược cho upstream để giữ quyền đối với phần bạn viết.

`mod-comparison.json` đối chiếu thư mục `../src` với tag Bruce `1.17`, commit
`2b6ba4d490bfcf94ce2574c6154537dbd5838c3d`. Kết quả ban đầu: 176 file trùng,
205 file sửa, 47 file chỉ có trong bản mod. Đây không phải chứng nhận tác giả:
file mới có thể đến từ phiên bản khác, thư viện hoặc dự án khác. Lịch sử commit,
bản nháp và nguồn của từng đoạn mã mới là chứng cứ cần kiểm tra.

Bản viết lại không nhập mã từ `../src` hay `../bruce-original-1.17`. Hai cây đó
chỉ là đối tượng đối chiếu nguồn gốc; không là dependency của build. Ý tưởng menu,
chức năng, chân phần cứng và API công khai được thể hiện bằng mã mới. Vì phiên
làm việc đã xem mã cũ, đây không phải một quy trình “clean room” có hai nhóm tách
biệt và không được mô tả như vậy.

Việc gỡ file đã phân phối không tự động xóa nghĩa vụ hoặc quyền đã phát sinh từ
những bản cũ. Bản viết lại không thay đổi license của chúng. Quay video giao diện
khác với phân phối firmware; nội dung ảnh, âm thanh hoặc logo trong video vẫn có
thể có quyền riêng.

Tham khảo:
- Bruce 1.17 LICENSE, các mục 5, 6, 10, 13:
  https://github.com/BruceDevices/firmware/blob/1.17/LICENSE
- GNU FAQ về quyền đối với sửa đổi và cấp phép đóng góp:
  https://www.gnu.org/licenses/gpl-faq.html
- WIPO: Intellectual Property Adjudication in Viet Nam, phần bản quyền, Điều 15:
  https://www.wipo.int/edocs/pubdocs/en/wipo-pub-1081-3-en-intellectual-property-adjudication-in-viet-nam.pdf

## Cập nhật về phần tự viết trong mod

Chủ dự án xác nhận có nhiều phần do họ tự viết, và `bruce-original-1.17` là
bản gốc để đối chiếu. Có thể tái sử dụng phần đóng góp họ thực sự sở hữu, không
cần mặc định bỏ tất cả mã mod. Nhưng diff không tự phân định quyền của từng
đoạn; các file Flipper port còn gọi API Bruce/Arduino và chưa có thông tin
nguồn gốc riêng đầy đủ. Lần triển khai nRF hiện tại viết driver và UI mới theo
Nordic specification, không chép implementation/payload/asset từ port đó.

Menu ba app và khung giữa là yêu cầu về hành vi; icon, nét vẽ, bố cục chi tiết
và renderer được làm mới. ESP-IDF thay Arduino là lựa chọn kỹ thuật, không phải
một cách tự động thoát license nếu vẫn mang mã AGPL theo.

## Phần hình ảnh người dùng cho phép dùng

Chủ dự án xác nhận Naoya/BW16 là phần mình tạo và yêu cầu giữ lại. Bitmap Naoya được trích riêng từ biến đã chỉ định, hình PCB BW16 được dựng lại bằng SVG, không nhập menu/framework. Ghi nhận tại `assets/icons/user-assets.json`; việc xác nhận này chưa độc lập kiểm tra quyền đối với hình chân dung gốc. Nó không chuyển giấy phép của mã Bruce hoặc các đóng góp khác.

Chủ dự án đã cho phép port Tetris tự thêm và tái sử dụng các game xác định là do mình tự viết. Xem `game-provenance.json`. Megalodon/tururururu có credit IncursioHack và tồn tại trong Bruce gốc nên không coi là game chủ dự án tự viết; không nhập mã này vào bản đóng.
