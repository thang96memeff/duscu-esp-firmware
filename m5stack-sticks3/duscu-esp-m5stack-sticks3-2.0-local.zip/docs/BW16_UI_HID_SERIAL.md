# BW16 controls, update demo, Naoya Serial and QWERTY

Source-only revision,2026-11-17. No firmware build/link/export or preview.
The owner explicitly requested additive fixes while retaining their other code.
No existing source file was deleted. See the source snapshot and preservation
checks in `docs/development/verification-latest.json`.

## BLE HID controls

The existing nine root entries and spam/suite/ninebot screens remain. This work
adds a shared native ESP-IDF HID keyboard/consumer profile for Media, Presenter,
BLE Keyboard and BadBLE. Device name: **DUSCU Controller**, stable across tools.
The host must pair and enable input notifications. Encrypted link/notification
readiness is checked before reports are accepted. Each action sends a press and
an all-zero release; counts reflect accepted HID actions rather than UI ticks.
SDK report submission/file reads run in a worker so rendering and Back remain
responsive. Back/leave stops the profile and queued work. Mode switching shares
the existing controller rather than registering another GAP owner.

| Screen | Default BW16 controls | Extra controls retained |
| --- | --- | --- |
| Media | Up/Previous: volume up; Down/Next: volume down; OK: play/pause | Alternate toggles a selector for all six commands, including next/previous track and mute |
| Presenter | Up: previous slide; Down: next slide; OK: F5/Escape | Slide count/timer; Alternate opens existing next/previous/F5/black-screen commands |
| Keyboard | Opens QWERTY editor; OK accepts text, then OK on SEND transmits | Original character selector remains; Space/Enter/Edit controls added |
| BadBLE | Select payload, wait for pairing, run with progress, OK/Back stops | Hello World, Rickroll URL, CMD SysInfo, lock screen, quick text, stored file |

Built-in launch shortcuts target Windows. The generic HID transport sends
standard US-layout ASCII. Stored `.txt`,`.duck`,`.ducky`,`.badble` files are
chosen through Files; no typed path is required. Parsing supports REM, STRING,
STRINGLN, DELAY and named-key chords. Bounds:16KiB/file,255bytes/line,
512commands,6simultaneous non-modifier keys,60000ms/DELAY. Entire scripts are
validated before execution. Disconnect after starting aborts the job; initial
pairing waits up to60s. Syntax/SD/TX failures do not report completion.

SDK reference: [ESP-IDF5.5.1 HID public API](https://github.com/espressif/esp-idf/blob/v5.5.1/components/esp_hid/include/esp_hidd.h).
The transport/worker and script parser are original application code; this
change links the existing Apache-licensed SDK `esp_hid` component. Bluetooth
GATTS must be enabled, as in the existing board configurations. BLE5 uses its
own extended-advertising instance1; legacy BLE uses the shared GAP dispatcher.
No advertisement payload tables or spam algorithms were changed by this work.

## Portal Update

The BW16 reference currently impersonates an update page to collect WiFi
passwords. That credential-collection mechanism was not ported. The implemented
feature is explicitly **DUSCU Update Demo**: open local AP, captive DNS/HTTP,
self-contained monochrome page, Start button and18s simulated progress shared
between browser and device. No firmware is installed and no credentials are
requested or stored. POST start accepts no body. Actual page-open counts replace
the prior increment-on-tick counter for this screen.

Connect to `DUSCU Update Demo`, then open `http://192.168.4.1/` if the captive
window does not appear. OK/Back stops HTTP/DNS and restores the prior WiFi mode.
DNS bind/HTTP startup failures are reported and cleaned up. Existing other WiFi
rows and their implementations are retained, including WiFi Free. The portal
uses a separate HTTP control port so the file WebUI can retain its own server.

## Naoya API key over Serial

Choose **API key via Serial**, open Serial Monitor at115200, paste the raw Gemini
key and press Enter. Surrounding whitespace/double quotes are accepted. Existing
keys appear only as a masked prefix/suffix. Empty Enter or device OK keeps/saves
the current key; Back/Home, ESC or CANCEL exits input mode. CR, LF, CRLF,
backspace, overflow and invalid input are handled without echoing the key.
Successful input calls the existing AiClient/NVS save path automatically.
Gemini requests/models/history/HTTPS implementation remains unchanged.

`AI KEY` or `NAOYA KEY` starts the same paste session from CLI. Existing
`AI KEY <key>` and other AI commands retain their previous behavior; the former
continues to set RAM only until explicit AI SAVE. Ordinary CLI parsing is
suspended only during the paste session, as in the reference workflow, without
blocking or creating a competing UART reader.

## Shared keyboard

QWERTY9columns and the four BW16 IR character pages, with `Aa / space / del / ok`
on a separate row and initial focus on OK. Existing Telex remains a fifth page
for non-secret fields. Short/OLED screens use the native5×8 font; other screens
scale cell geometry to fit. Touch hit boxes use the same layout as drawing.
Byte counts/max length, UTF8 deletion, secret masking and Back-to-cancel remain.
Very small screens retain a compact fallback. Changes affect editor rendering
and navigation; callers retain their own save/validation behavior.

## Verification and limits

Host ASan/UBSan tests execute the HID worker with mocked SDK callbacks for both
BLE5 and legacy advertising, readiness gating, press/release, scripts, stop and
restart/failure paths. Real BLE/WiFi modules are tested with mocked services;
all9BLE/8WiFi rows remain. A separate test executes the actual update server with
mocked HTTP/WiFi/DNS, including rejection/redirect/cleanup/restart failures.
Portable tests cover script/Serial parsing, demo timing and QWERTY/touch geometry.
Portal JavaScript is exercised in Node without opening a preview. RF/IR workflow
regression and17Python tests pass. Preservation checks confirm23other WiFi/BLE
functions remain byte-identical to the turn-start backup.

The previous SDK/toolchain cache is unavailable; no full ESP-IDF type check,
link or on-device pairing/radio/Serial validation was performed. Host SDK mocks
do not establish hardware compatibility. All changes are in source and are not
contained in the previously exported firmware. Build only on a new request.
