# DUSCU-IDF:1.0 — Xingzhi Cube

Ứng dụng đang được viết lại bằng ESP-IDF, với renderer, giao diện và xử lý
nút/cảm ứng riêng. **Profile `xingzhi-cube` đã build thành công ngày 2026-11-15;
chưa thử trên bo thật.** CYD/OLED chưa build lại sau thay đổi mới. Các mục bên
dưới mô tả mã đã viết, không phải chứng nhận chức năng hoạt động trên thiết bị.
Binary cho Xingzhi Cube và hướng dẫn nạp ở [dist/xingzhi-cube](dist/xingzhi-cube/FLASH.txt).
Bản graphite trước đó ở `dist/previous-xingzhi-cube/` không phải UI hiện tại.

Mục tiêu là giữ kín mã ứng dụng khi phát hành và tuân thủ giấy phép các thành
phần bên ngoài. Không có bảo đảm pháp lý tuyệt đối. Không nhập mã ứng dụng Bruce. Riêng bitmap Naoya và hình BW16 được dùng theo xác nhận quyền sở hữu và yêu cầu của chủ dự án; hai cây tham chiếu đã được đọc nên đây
không phải quy trình clean-room có nhóm tách biệt. Xem
[thành phần](THIRD_PARTY.md), [quyền đối với mã mod](docs/AUTHORSHIP.md)
và [đối chiếu tính năng](docs/FEATURE_PARITY.md).
Việc viết lại không xóa nghĩa vụ của các bản Bruce mod từng phân phối.

Profile hiện tại: **Xingzhi Cube N16R8, flash 16 MB, PSRAM Octal 8 MB, CPU 240 MHz**. Phân vùng mới chuyển SPIFFS từ `0x210000` sang `0x310000`; sao lưu tệp trước khi chuyển từ bản 4 MB. Firmware không tự format.

## Bố cục dự án

Mã được chia thành `src/core/`, `src/hal/`, `src/ui/` và `src/modules/<chức năng>/`; file sinh tự động nằm trong `generated/`. Xem [sơ đồ thư mục](docs/SOURCE_LAYOUT.md) và [hướng dẫn thêm chức năng](docs/EXTENDING.md).

## Xem UI trước khi build

Mở trực tiếp [bản xem Xingzhi Cube](preview/xingzhi-cube.html) hoặc
[preview/index.html](preview/index.html) trong trình duyệt. Cả hai là HTML tự
chứa font/icon/script và có ảnh SVG tĩnh khi JavaScript bị chặn. Trang
chạy offline, không gọi API hoặc kết nối thiết bị; tác vụ trong trang là mô
phỏng thiết kế. Có ba profile màn hình, phím điều hướng, chạm ba vùng, thanh
xem từng frame và tùy chọn tắt animation.

- TFT: mặc định đen/trắng, có palette màu riêng và rainbow; cạnh chữ có khử răng cưa, ba ứng dụng trên màn hình, khung cố định ở giữa; icon 1-bit; Naoya/BW16 theo phần người dùng sở hữu.
- OLED: một mục có icon lớn, nhãn và dãy chấm chỉ vị trí.
- Animation: carousel sprite 160ms, cache icon 1-bit, dirty rectangle và DMA;
  submenu trượt từ bên phải220ms trên nền đã cache, có lưu bật/tắt chuyển động.
  Vạch sóng180ms/bước; tên tính năng dùng font18px. Đo bằng Serial `PERF`.
- [Ảnh ba màn hình](preview/duscu-ui-preview.png),
  [bảng tám frame](preview/duscu-focus-frames.png),
  [GIF chuyển focus](preview/duscu-focus-animation.gif),
  [menu lớp hai](preview/duscu-submenus-preview.png).

Xem [thiết kế và giới hạn bản xem thử](docs/UI.md).
[SVG để tự sửa](assets/duscu-icons-svg.zip), [hướng dẫn icon](assets/icons/README.md),
[bộ icon đậm](preview/icons-contact-sheet.png), [hiệu ứng sóng](preview/icon-waves.gif).

## Nguồn chức năng hiện có

| Nhóm | Đã viết nguồn; cần build và kiểm tra thực tế |
| --- | --- |
| Display / input | ST7789, ILI9341, SSD1306; Noto Sans tiếng Việt; nút và XPT2046 tap/vuốt |
| WiFi | Quét AP, kết nối STA bằng bàn phím trên thiết bị hoặc Serial, AP WPA2 mật khẩu ngẫu nhiên, thông tin mạng, MAC cục bộ ngẫu nhiên, thống kê khung, ghi PCAP giới hạn, phân tích kênh, TCP client/listener |
| BLE | Scan thụ động 5 giây, hai nhánh API BLE4/BLE5 theo SDK; service beacon riêng Duscu; BLE spam tên/Swift Pair/UUID |
| RF | CC1101 SPI; RSSI trực tiếp và lịch sử, quét phổ 21 điểm, dạng sóng khung đã học, 315/433.92/868 MHz; thu/lưu/tải OOK, replay một lần |
| nRF24 | Driver thanh ghi mới, probe, RPD spectrum 126 kênh RX-only, theo dõi kênh, register inspector; không chép nguyên Flipper port |
| IR | Remote nhiều nút, lưu/mở .ir, phát RMT; TV-B-Gone NA137/EU138; Universal Power/CH±/VOL±/Mute/Input, lặp tùy chọn; nhiễu IR38/40/56kHz hoặc quét24–60kHz. Dữ liệu CC0 và CC BY-SA có giấy phép riêng; nguồn mới chưa build |
| BW16 | UART scan/stop/auth, lọc 2.4/5 GHz, đa chọn, deauth/flood/beacon/portal theo lệnh companion, chạy nền, gửi lại, terminal; chưa có firmware BW16 mới đi kèm |
| naoyaAI | Gemini HTTPS, nhập API key/model/câu hỏi trên thiết bị, Telex tùy chọn, chọn model từ API, hội thoại giới hạn, lưu key/model khi chủ động chọn; cần key và kết nối |
| Clock | Giờ hệ thống/SNTP, mặt số/kim, stopwatch, countdown tạm dừng được |
| Files | Worker SD/SPIFFS, cache danh sách, text UTF-8 theo trang, xem PNG/JPEG baseline/BMP co vừa màn hình 1-bit; USB mass storage SD trên S3, công cụ file Serial và WebUI token |
| Games | Tetris do chủ dự án cho phép port, giữ luật và khối của bản mod; Reef Dash viết riêng, điểm cao lưu NVS |
| Settings | Ngôn ngữ, độ sáng, đảo màu, animation lưu NVS; thông tin cuộn được, thanh flash/tệp/SD/RAM/PSRAM và giấy phép |

Phạm vi tính năng và các giới hạn hiện tại chưa bao phủ mọi công cụ tham chiếu. Các phần còn thiếu được ghi trong
[FEATURE_PARITY.md](docs/FEATURE_PARITY.md), gồm protocol decoder nâng cao,
HID, SSH/VPN và nhiều công cụ nâng cao. Không có kết quả quét giả hoặc số đo pin
mẫu. Chưa có OTA. Xem [VALIDATION.md](docs/VALIDATION.md) trước khi đánh giá độ sẵn sàng.

## Phần cứng và điều khiển

Thông số nằm trong `src/hal/board.h`, dựa trên sơ đồ/chân đã có; chưa xác nhận trên
thiết bị thật.

| Profile | Hiển thị / input |
| --- | --- |
| `xingzhi-cube` | ST7789 240×240: MOSI10 CLK9 CS14 DC8 RST18 BL13; Prev39 Next40 Select0 |
| `m5stack-sticks3` | ST7789P3 240×135 ngang: MOSI39 CLK40 CS41 DC45 RST21 BL38; A11 B12; M5PM1 pin/nguồn |
| `cyd-2432s028` | ILI9341 320×240: MOSI13 CLK14 CS15 DC2 BL21; Select0; XPT2046 CLK25 MOSI32 MISO39 CS33 IRQ36 |
| `esp32-oled-096` | SSD1306 128×64, I2C21/22, 0x3C; Prev34 Next35 Select0 |

Nút nối xuống GND. GPIO34/35 trên ESP32 cần pull-up ngoài. RF/IR, SD và BW16
có bảng chân riêng trong `board.h`; OLED generic chưa có chân RF/IR mặc định.
CYD dùng chung GPIO22/27 cho IR và CC1101. Xingzhi dùng GPIO1/2 cho BW16 hoặc
CC1101: phải dừng ngoại vi trước khi đổi chế độ. RF/SD dùng chung bus SPI với CS riêng.

- Ba nút: Prev/Next/Select; giữ Select 500ms để Back, Prev/Next tự lặp.
- CYD một nút: nhấn ngắn Next; giữ 250–499ms rồi nhả để Select; giữ 500ms Back.
- M5StickS3: A chọn/giữ500ms Back; B nhấn một lần Next, hai lần Previous, giữ500ms Back. [Cấu hình và chân M5StickS3](docs/M5STICKS3.md).
- TFT: chạm trái/phải để chuyển app, chạm giữa để mở; chạm dòng menu, mũi tên để Back.
  Vuốt trái/phải chuyển mục, vuốt xuống Back. OLED dùng nút.
- Text: Prev/Next đổi trang, Select đọc trang sau; Back thoát cả khi worker đang đọc.
  Xem [FILE_VIEWER.md](docs/FILE_VIEWER.md) về cache, ảnh và giới hạn.
- Clock: Select bắt đầu/tạm dừng; stopwatch đã dừng dùng Prev/Next để reset;
  timer đã dừng dùng Prev/Next đặt 5/10 phút.

## Serial 115200

Gửi từng dòng kết thúc bằng newline; `HELP` liệt kê lệnh. Ví dụ:

```text
PERF RESET
PERF
BATTERY
NRF INFO
NRF SCAN
NRF STOP
SCAN WIFI
SCAN BLE
STATUS
WIFI TenMang<TAB>MatKhau
AP START
TCP LISTEN 9000
SD MOUNT
FILE LS /storage
FILE LS /sd
WEB START
WEB TOKEN
AI KEY <key>
AI MODELS
AI MODEL <model-tu-danh-sach>
AI ASK <cau-hoi>
STOP
```

`<TAB>` là ký tự tab thật. WiFi credentials ở RAM; AI key/model chỉ lưu NVS khi
`AI SAVE` hoặc chọn lưu trong UI. Khi kết nối, SNTP đặt giờ; hiển thị UTC+7.
WebUI trên HTTP8080, API dùng Bearer token ngẫu nhiên xem trên màn hình hoặc
`WEB TOKEN`. HTTP không mã hóa đường truyền; chỉ bật trên mạng tin cậy. WebUI
không tự chạy khi khởi động. Upload tạo file mới, tối đa 1MB, không ghi đè.

FS không tự format khi mount lỗi. `FORMAT YES` xóa phân vùng storage theo lệnh
chủ động. SD mount không format. Lệnh sửa file/format/unmount dừng WebUI trước
khi thao tác. Xem `HELP` cho cú pháp FILE/BW/TCP đầy đủ.

## Kiểm tra nguồn và preview — không build firmware

```sh
python3 -m venv .venv-review
.venv-review/bin/pip install -r tools/requirements-review.txt
.venv-review/bin/python tools/check_cpp_syntax.py
.venv-review/bin/python tools/make_font.py --check
.venv-review/bin/python tools/make_menu_font.py --check
.venv-review/bin/python tools/generate_icons.py --check
.venv-review/bin/python tools/render_ui_frames.py
python3 tools/build_preview.py
python3 -m unittest discover -s tests -p 'test_*.py'
node tests/preview_test.js
python3 tools/audit_sources.py
git diff --check
```

Module registry, driver, renderer và cách mở rộng được mô tả trong
[EXTENDING.md](docs/EXTENDING.md). Bộ kiểm tra portable bổ sung nằm ở
`tests/graphics_test.cpp`; biên dịch bằng compiler C++17 trên host.

Tree-sitter chỉ kiểm tra ngữ pháp C++, không kiểm tra kiểu/API SDK/linker.
Audit văn bản không chứng minh quyền tác giả hoặc việc không xâm phạm.
Font bitmap phái sinh từ Noto Sans vẫn theo SIL OFL1.1, có nguồn/phiên bản/hash
trong `third_party/font/`; không áp dụng license độc quyền ứng dụng cho font.

## Build về sau

Chủ dự án đã yêu cầu build Xingzhi và bổ sung M5StickS3 ST7789. Kết quả build cục bộ được ghi trong `dist/<profile>/build.log`; chưa kiểm tra M5StickS3 trên bo thật.
Platform được pin ở
pioarduino55.03.34 / ESP-IDF5.5.1.251106, framework ESP-IDF, không dùng Arduino
hay `../lib`. Bốn environment có trong `platformio.ini`.

```sh
pio run -e xingzhi-cube -j 2
pio run -e m5stack-sticks3 -j 2
```

Build ở `.pio-idf/build/`. Xingzhi N16R8 dùng flash16MB, app3MiB, SPIFFS tại0x310000 và PSRAM Octal; CYD/OLED giữ layout4MB riêng. Không nạp firmware ESP32 lên BW16.
`tools/package_firmware.py <environment>` **tự chạy build lại** rồi đóng ZIP
cục bộ ở `dist/`. Cần hoàn tất rà soát notice,
CA bundle và thử phần cứng trước khi dùng nó cho bản phân phối.

## Ba cây dự án và bản lưu

- `../bruce-original-1.17/`: tag1.17, commit
  `2b6ba4d490bfcf94ce2574c6154537dbd5838c3d`, giữ AGPL gốc.
- `../src/`: bản Bruce mod, không chỉnh trong lần viết lại này.
- Thư mục này: nguồn Duscu mới, không link hai cây trên làm dependency.

Bản lưu riêng tư trước thay đổi ở đường dẫn trong `docs/rewrite-backup.txt`;
không nằm trong gói mới. Lịch sử Git cũ được giữ nguyên, không đổi license hồi tố.

## Bổ sung Cài đặt / màu / hình nền

Cài đặt đã tách thành module: xoay0/90/180/270, preset ST7735/ST7789/ILI9341/ILI9488 và kích thước/offset riêng, cấu hình2/3/5 nút và GPIO có kiểm tra xung đột, tốc độ lặp, đảo nút game, vuốt dọc, startup/hide apps, icon ảnh, ngôn ngữ JSON, dim/sleep và khôi phục cấu hình. Preset là cấu hình cho panel tương ứng có cùng bus/pin; không tự nhận diện hay biến panel khác thành phần cứng tương thích. Chưa thử các panel này ngoài profile build.

Palette: White/Cyan/Amber/Lime/Magenta/Red, RGB tự nhập và rainbow. Hình nền PNG/BMP/JPEG baseline được giải mã nền, crop/cache RGB565, không đọc SD trong render; chọn ảnh trong Files rồi OK để đặt nền, hoặc chọn Chọn ảnh trong Tệp ở Settings. Dùng ảnh tự sở hữu. Tắt nền bằng Clear wallpaper. Các JSON/font ngôn ngữ chưa bảo đảm mọi ký tự ngoài bộ glyph Latin/Vietnamese.

Tetris: Prev/Next di chuyển, OK xoay, hai nút Prev+Next cùng lúc thả nhanh; Up/Down khi có5 nút, giữ OK để Back. Giữ Prev+Next lúc khởi động để khôi phục màn hình/nút mặc định nếu chọn sai profile.

## Web AP điều khiển đa năng

WiFi → Điều khiển Web AP mở dashboard nội bộ tại `http://192.168.4.1`. Mật khẩu AP và token được hiển thị trên máy; không dùng mật khẩu ghi cứng. Xem [WEB_AP.md](docs/WEB_AP.md) để dùng quản lý file, cấu hình, WiFi đã lưu và điều khiển màn hình/nút thật. Tính năng không tự bật lúc boot. Trạng thái build hiện tại ghi trong `docs/development/CHECKPOINT.md`.
