# Web AP Control

## Mở và ghép nối

1. WiFi → Điều khiển Web AP. SSID mặc định `DUSCU-Web`,WPA2; đọc mật khẩu thực tế và token trên màn hình. Up/Down cuộn thông tin trên màn nhỏ.
2. Kết nối điện thoại/PC với AP,mở `http://192.168.4.1`,nhập token. Không có dịch vụ cloud hay tài nguyên CDN.
3. OK trở lại menu nhưng giữ Web AP chạy. Back giữ trên màn thông tin tắt Web AP. Chọn lại mục Web AP cũng tắt; web có nút tắt riêng. AP không tự bật lúc boot.

## Chức năng

- Trạng thái thật:tên thiết bị/SSID,phiên bản,uptime,heap,pin,số máy đang kết nối,kết quả lệnh. Mật khẩu mạng đã lưu không được trả lại quaAPI.
- Catalog mở các app đang hiện trên máy; không chạy tự động một chức năng con. Các phímUp/Down/OK/Back/Home tác động qua cùng đường xử lý UI với nút vật lý. Nút vật lý có ưu tiên; giữOK500ms làBack,giữUp/Down lặp. Editor đang mở chặn chuyển app từ catalog để không mất nội dung.
- Live lấy khung hình thật từ buffer đã trình bày,gồmUI,ảnh/GIF và nền. Chuyển4mức xám2bit,giữtỉlệ,tối đa240×240,không dựng lạiUI ởtrìnhduyệt. Giới hạn4capture/s,chỉ chụp khi đã có frame mới; framebuffer chỉ cấp khi live và nhả khi phiên hết hạn. Lease một trìnhduyệt6giây,hàng đợi nút16mục; mất kết nối không để phím bị giữ. ThiếuRAM trả lỗi,không mở phiên.
- Files:SPIFFS/SD,mountSD,danh sách64mục/trang,download,upload tốiđa16MiB,rename,copy,xóa có xác nhận,tạo thư mụcSD. Giữ đúng hoa/thường. Không upload đè. Upload gián đoạn xóa file mới chưa hoàn chỉnh. SD khóa khiUSBmass-storage độc quyền; dùng storagelease chung. `/config` không nằm trong vùng tệp công khai. Không thêm chức năng format bộ nhớ.
- Tên hiển thị/SSID/mật khẩuAP lưu vàoNVSnamespace riêng`web_ap`. ĐổiSSID/pass khởi động lạiAP; kết nối và ghép token mới. Không đổi tênWiFiFree hay cấu hình của các chức năngWiFi khác.
- Tốiđa4WiFi đã lưu trongNVSriêng:thêm/cậpnhật,kết nối qua serviceSTA hiện có,xóa có xác nhận. Không tự nối từdanh sách này lúcboot. ESP32-S3 chỉ2.4GHz; không giả hỗ trợ5GHz.
- Cấu hình độ sáng,xoay,màu/rainbow,ngônngữ,animation,invert dùng bộ ghi settings hiện có;không sửa pinmap hoặc chức năngSettings. Thayđổi geometry trở vềHome để không giữ media decoder theo viewport cũ.

## Vòng đời và giới hạn

Web AP tạm nhường radio/HTTP80 khi chọn một chức năngWiFi khác. Khi quay lại/thoát,AP mở lại cùngSSID/password/token; nếu scanner vẫn chạy thì chờ hoàn thành. Các nhánhWiFi hiện hữu không được viết lại; không thêm API tự động deauth/spam. `services.cpp`,network backend,WiFiFree vàPortal server giữ nguyên. HTTP worker không gọi UI trực tiếp:job settings/app/key được xử lý trên main loop. API được bảo vệ bằng token độc lậpWPA2 và không nhét token vàoURL. Upload/download có deadline,chunks1KiB;không giữ màn hình/radio mutex khi gửi frame qua mạng.

Live hiện là ảnhxám,không phải luồngvideoRGB565 hay cam kếtFPS trên bo. Không có chức năng flashOTA,format hoặc sửa tênWiFiFree trongdashboard. Log và kiểmthử xemCHECKPOINT; không gọi ảnhBINcũ làsourcehiệntại.

## Nhãn sản phẩm

NhãnBLE và văn bảnmặcđịnh dùngDUSCU. Source ứng dụng không còn tên sản phẩm thamchiếu cũ. ReaderSubGHz chấp nhận header dạngvendor-labelled`... SubGhz File`,vẫnđọc filelegacy màkhông nhúng nhãnvendor trongcode. Chỉ hồsơnguồngốc,giấyphép và lịch sử kiểmđịnh giữ tênthamchiếu khi cầnthiết; không xóa thôngbáo bảnquyền bắtbuộc.
