# Boot and device configuration

Every boot runs a dense terminal log for at least3seconds. Its first line is
exactly `duscu.booting:true;`. Hardware initialization runs in parallel; a slow
device can extend this time. The terminal is followed by the boot image for
3seconds, then the normal interface. There is no question or required button
press. On the first successful startup, the existing settings writer saves the
device defaults automatically; configured boots keep the saved settings.

The terminal uses the native BW16 OLED 5×8 bitmap (6×9 cells), including its
compact Vietnamese glyph composition. All lines share the same scrollback:
`duscu.booting:true;` starts at the top and scrolls off when the viewport fills.
Scrolling advances in pixels rather than pinning a header or jumping full rows.
The optional question strings remain in source but `show_question=false` keeps
them off. Neither first nor later boots show the question with this setting.

Edit terminal/image durations and log density in
[`src/ui/boot_content.h`](../src/ui/boot_content.h). Both durations default to
3000ms. First-run completion uses the existing normal-interface choice1; it
does not reset previously saved preferences. A failed save still offers OK to
retry or Back to continue through the boot image temporarily. Temporary
continuation leaves setup pending for the next boot.

After the terminal on every successful boot, the embedded
[`assets/boot/duscu-esp-boot.jpg`](../assets/boot/duscu-esp-boot.jpg) is displayed.
It remains visible for at least3seconds after decoding completes.
The126×128 JPEG is embedded unchanged (7,279bytes vs32,256bytes rawRGB565), decoded
once, scaled with bilinear interpolation and centered without stretching or
cropping. Small screens scale it down; large screens enlarge it. Black margins
preserve aspect ratio, and OLED uses ordered1bit dithering. Image RAM is released
after startup. If decoding or memory fails, boot proceeds to the interface
without waiting on a missing picture. Initialization failures remain visible
in the terminal instead of being covered by the image.
Use a baseline RGB JPEG when replacing it; a later firmware build is required.

## Settings file

The `config` SPIFFS partition occupies the final128KiB of flash, separately from
the user file partition. Settings are stored as schema2JSON at
`/config/settings.json`: board identity, first-run completion, rotation/panel
geometry, language, colors/rainbow, wallpaper/icons, brightness, timing, buttons
and peripheral GPIO pins. Open Files→Device configuration to browse this file.
Storage uses a verified temporary file,`fsync`, rename and a `.bak` backup;
an invalid primary can be retained as `.invalid`. A valid backup or interrupted
temporary file can be recovered at startup.

Pin overrides are validated before use: reserved LCD/PSRAM/USB/audio pins,
GPIO capabilities, conflicts, SPI/UART pairs and ADC selection. Settings edits
are applied to GPIO at the next reboot, before peripheral initialization.
Screen/button changes retain their existing Settings controls.

NVS remains a recovery and old-firmware migration mirror. If the new partition
is missing, corrupt or contains unrecognized data, firmware preserves it and
uses the NVS fallback. Only an entirely erased configuration partition may be
initialized automatically. Do not assume the file exists when compatibility
fallback is reported.

Serial commands:

- `CONFIG INFO`: file path, storage status and first-setup flag.
- `CONFIG FIRSTBOOT`: mark initial setup pending again, preserving current
  preferences. The next boot saves completion automatically while the question
  remains disabled. Requires an explicit serial command; no automatic reset.

The existing native recovery button combination resets hardware settings in RAM
before device initialization and saves safe defaults after a successful startup.

## Migrating an existing device

**Back up files in internal flash before flashing the new partition table.**
The user SPIFFS partition is128KiB smaller so that `config` has its own space.
Its start and the current app/NVS positions remain unchanged, but an old
filesystem may no longer mount after its size changes. There is no automatic
file migration or erase of nonblank data. SD card contents are unaffected.
This source change has not built or flashed a firmware image.
