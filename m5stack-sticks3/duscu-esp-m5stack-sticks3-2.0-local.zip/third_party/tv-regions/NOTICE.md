# TV-B-Gone NA / EU waveform data

Original authors/capture credit: **Mitch Altman and Limor Fried, 2009**.
Original title: TV-B-Gone Firmware / Generation 3 TV POWER code tables.
Source: https://github.com/adafruit/TV-B-Gone-kit
Pinned revision: `4197eeb212aa34b5ad07efb0684102a93195da87`.
Original table: `firmware/WORLDcodes.c`, preserved as `upstream-WORLDcodes.c`.

This directory contains measurement data, not an imported transmitter or UI.
The separately written Duscu reader/transmitter is outside this data directory.

**License: Creative Commons Attribution-ShareAlike 3.0 Unported**.
Full license: `LICENSE`, and https://creativecommons.org/licenses/by-sa/3.0/ .
The upstream repository includes that license. Its original firmware notice also
cites CC BY-SA 2.5; section4(b) of that license allows later versions retaining
the same license elements. The converted dataset is offered under3.0.

Duscu changes: expand the packed table indices to microsecond pulse durations;
retain the source ordering for NA137/EU138; store exact shared waveforms once
(270 unique records) in an inert binary resource. Carrier frequencies retain
their specified values, including unmodulated entries. Shared timing tables
are resolved across both source sections before region-index selection.

`signals.json` is an editable, human-readable version of the converted data.
`tv_regions.dat` contains the same waveforms. `provenance.json` records source,
resource hashes, counts and the transformation. These files and this notice
must accompany redistributed firmware packages. Recipients may copy, modify
and redistribute this data under its own license; the application license does
not impose restrictions on this data.

Data-file layout, little endian: magic`DSCTVDB1` (8bytes), unique count/NA count/
EU count/reserved (uint16 each), NA then EU arrays of uint16 record indices,
then12bytes/unique record (frequencyHz:uint32, pulse count:uint16,
reserved:uint16, absolute pulse offset:uint32), then uint32 microseconds.
Pulse levels alternate mark/space. Frequency0 means no modulation.

No warranty. Geographic labels describe the upstream code collections and do
not guarantee coverage of every television or country.
