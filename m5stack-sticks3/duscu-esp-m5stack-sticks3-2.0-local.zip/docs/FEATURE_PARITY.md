# Cập nhật nguồn mới: IR/RF/nRF/BLE/GIF

Đợt này **chưa build** theo yêu cầu chủ dự án; xem `REMOTE_AND_RADIO.md` cho thao tác và giới hạn thực tế. IR/RF đã có bộ chọn tệp, lưu và phát remote; GIF có giải mã nhiều khung riêng; BLE thêm quét liên tục/AD/RSSI/JSON/beacon; nRF thêm worker và Spectrum80. Chưa đạt tương đương toàn bộ Bruce hoặc Bruce mod, chưa kiểm tra bo thật. Các bảng lịch sử bên dưới có thể mô tả bản trước.

# Đối chiếu chức năng, không sao chép triển khai

Mốc tham chiếu: Bruce **1.17**, commit
`2b6ba4d490bfcf94ce2574c6154537dbd5838c3d`.
Phạm vi ban đầu: chín mục Duscu đã có; nay bổ sung nRF theo yêu cầu chủ dự án. Không bổ sung các nhóm RFID/NFC, GPS,
Ethernet, LoRa, trò chơi hay script engine vào phạm vi lần này.

Theo yêu cầu tiếp theo, `xingzhi-cube` đã build thành công ngày 2026-11-15.
CYD/OLED chưa build lại, chưa thử phần cứng. Trạng thái “đã viết nguồn” không
có nghĩa tính năng đã được thử hoặc được xác nhận pháp lý; xem `VALIDATION.md`.

## Quy tắc nguồn gốc

- Tên chức năng, hành vi, chân GPIO, định dạng file và giao thức dùng để lập đặc
  tả. Không chuyển hàm/class AGPL/GPL từ cây Bruce/mod. Riêng Naoya bitmap/BW16 geometry dùng theo quyền sở hữu mà chủ dự án xác nhận; xem provenance riêng.
- Mã mới dùng ESP-IDF và đặc tả nhà sản xuất. Các thành phần bên ngoài phải có
  nguồn, phiên bản và license cho phép hình thức phân phối dự kiến.
- GPL/AGPL không tự biến thành mã riêng khi đổi tên, dịch ngôn ngữ hoặc chia module.
- Không áp dụng một license chung của Bruce lên mọi thư viện bên trong; kiểm tra
  upstream thật của từng thành phần. Không bỏ notice của phần được phép dùng.
- Hai cây tham chiếu đã được đọc trong phiên này; đây không phải quy trình clean
  room có nhóm tách biệt. Kiểm tra văn bản chỉ hỗ trợ rà soát, không bảo đảm pháp lý.

## WiFi

Nguồn chức năng: `core/menu_items/WifiMenu.cpp`, `modules/wifi/wifi_atks.cpp`.

| Chức năng tham chiếu | Hướng triển khai riêng / trạng thái |
| --- | --- |
| Quét, AP ẩn, thông tin AP | API quét ESP-IDF; đã viết nguồn quét và thông tin từng AP; chọn AP/nhập mật khẩu trực tiếp trên thiết bị |
| Kết nối / ngắt / AP nội bộ | Đã viết nguồn STA trên thiết bị/Serial và SNTP, AP WPA2 mật khẩu ngẫu nhiên, ngắt riêng |
| Phân tích kênh | Thống kê từ kết quả quét và khung 802.11 thu thực tế |
| Sniffer, xuất bản ghi | Đã viết nguồn thống kê header và PCAP, snaplen 256 byte, file tối đa 512KB |
| Giám sát deauth/disassoc, tín hiệu bất thường | Thống kê thụ động, tách quan sát khỏi kết luận có tấn công |
| TCP server/client, Telnet | Đã viết TCP client/listener lwIP qua Serial; chưa thương lượng giao thức Telnet |
| Scan hosts | Kiểm tra kết nối/host trong mạng do người dùng chọn; chưa viết hoàn chỉnh |
| SSH, SOCKS4, WireGuard | Cần triển khai giao thức/thư viện có license phù hợp; chưa nhập dependency |
| WiFi attack menu | Có deauth, beacon, Karma, portal sao chép, handshake; chưa được chuyển sang bản mới |
| NetCut, Responder, Brucegotchi, WiFite/WPS, password recovery | Cần đặc tả và rà soát riêng từng giao thức/thư viện; chưa triển khai |
| SDR | Có điều kiện phần cứng ESP32-S3, không tương đương với mọi bo ESP32 |
| Dual-band analyzer | Chỉ xuất hiện trên profile ESP32-C5; ba profile Duscu hiện tại không có radio 5GHz |
| MAC, mạng ẩn, thông tin kết nối | Đã viết MAC cục bộ ngẫu nhiên, thông tin STA, kết nối SSID qua Serial |

## BLE

Nguồn chức năng: `core/menu_items/BleMenu.cpp`, `modules/ble/README.md`.

| Chức năng tham chiếu | Hướng triển khai riêng / trạng thái |
| --- | --- |
| Scan, nhận diện service/quảng bá | Scan thật; đã viết nguồn BLE 4.2 cho ESP32 và BLE 5 cho S3 |
| Beacon | Đã viết payload service Duscu riêng mỗi giây; không lấy bảng payload Bruce/Flipper |
| Keyboard, media, presenter, Bad BLE | Cần HID/GATT và hành vi ghép đôi được triển khai riêng; chưa hoàn tất |
| BLE spam | Đã viết state machine quảng bá tên/Swift Pair/UUID, tuần tự stop/configure/start; chưa có bảng Apple/Google popup hay HID |
| BLE Suite, Ninebot | Có trong Bruce; chưa triển khai hoặc khẳng định tương đương |
| Các suite CVE, bypass, fuzzer, chuỗi khai thác | Danh mục tham chiếu, không coi các chuỗi thông báo của Bruce là bằng chứng hiệu quả |

## RF

Nguồn chức năng: `core/menu_items/RFMenu.cpp`. Phần nguyên lý lấy từ datasheet
CC1101, không lấy driver/ProtoPirate/keystore từ Bruce.

| Chức năng tham chiếu | Hướng triển khai riêng / trạng thái |
| --- | --- |
| Scan/copy, RAW record | Đã viết nguồn thu xung OOK và lưu/tải định dạng Duscu |
| Custom SubGHz / phát lại | Đã viết nguồn phát một khung đã học, chưa có parser .sub tương thích |
| RSSI / tần số | Đã viết nguồn phát hiện chip, đọc RSSI, chọn 315 / 433.92 / 868 MHz |
| Spectrum, waveform, waterfall | Đã viết nguồn RSSI history, phổ 21 điểm quanh trung tâm ±1MHz và waveform từ khung đã thu; chưa waterfall |
| Listen | Cần hardware audio và cấu hình chân; chưa có trong profile mới |
| ProtoPirate / bộ giải mã | Không nhập code, bảng key hoặc registry. Cần viết theo đặc tả từng protocol |
| Bruteforce / jammer | Chưa triển khai; không được đánh dấu là đã có |
| Chân / module / tần số | Giá trị phần cứng theo profile, sẽ tách thành cấu hình Duscu |

## IR

Nguồn chức năng: `core/menu_items/IRMenu.cpp`.

| Chức năng tham chiếu | Hướng triển khai riêng / trạng thái |
| --- | --- |
| IR Read / học mã | Đã viết nguồn ghi thời lượng xung từ mắt thu |
| Custom IR / replay | Đã viết nguồn RMT phát lại khung đã học ở 38kHz |
| Lưu / tải | Định dạng `DUSCU_PULSES`, tự định nghĩa; đã viết nguồn |
| NEC / Sony / RC5 và protocol khác | Viết encoder/decoder theo đặc tả công khai, không port hàm Bruce |
| TV-B-Gone | Worker RMT hủy được, bộ dữ liệu CC0 đã pin; không tái sử dụng `WORLD_IR_CODES.h`; chưa thử TV thật |
| IR jammer | Chưa triển khai |
| Chân / carrier / số lần phát | Cần cấu hình rõ, không dùng mặc định lặp vô hạn |

## Clock / Files / Settings

| Nhóm | Chức năng Bruce được đối chiếu | Trạng thái Duscu |
| --- | --- | --- |
| Clock | Đồng hồ, timer, đặt giờ | Đã viết giờ thực, SNTP, mặt số/kim, stopwatch, countdown |
| Files | SD, flash FS, WebUI, truyền file/commands, USB mass storage | Đã viết SPIFFS/SD, worker/cache, text theo trang, ảnh PNG/JPEG baseline/BMP 1-bit, quản lý file Serial và WebUI upload/download/delete dùng token; chưa USB mass storage |
| Settings | Display/UI, âm thanh/LED, hệ thống, clock, pins, mạng, power, factory reset | Đã viết brightness/language/inversion/animation/NVS, giờ Serial/SNTP; chưa âm thanh/power/factory reset đầy đủ |

## BW16 / naoyaAI

Hai nhóm này **không có trong Bruce gốc 1.17**. Chỉ tham chiếu tính năng của bản
mod; quyền với mã trong các file mới chưa được xác nhận bằng việc so sánh diff.

- BW16: đã viết UART transport 115200, scan/stop/trạng thái, chọn ID, terminal
  và đổi chân qua Serial. Dùng thông tin tương tác `sc`, `sl:<ids>`, `stop`,
  `AUTH:CHECK`; không nhập firmware, bypass hay key companion. Chưa thử bo;
  không đóng gói firmware BW16 cũ, chưa có firmware mới.
- naoyaAI: đã viết Gemini HTTPS/cJSON, lấy model từ API, gửi câu hỏi chủ động,
  lịch sử giới hạn, xử lý lỗi và tùy chọn lưu key/model. Không nhập ảnh/prompt
  sáng tạo hay bảng model từ mod. Chưa thử TLS/API trên bo thật.

## UI và mở rộng

DUSCU ESP (đen–trắng): ba app trên TFT, khung giữa, mười icon riêng, OLED gọn. Sprite cache,
framebuffer 1-bit, dirty rectangle, truyền DMA vùng đổi, animation 160ms, sóng tuần tự, submenu trượt và đo
PERF trên bo. Status bar có ADC pin/charging Xingzhi, không tạo giá trị giả.
RF/nRF dùng `AppModule` và registry; xem `EXTENDING.md`, `UI.md`, `VALIDATION.md`.

## nRF24 từ yêu cầu bổ sung

Bản mod có Flipper-port NRF với RPD/register inspection và các chế độ carrier/
pump/jammer. Chưa có provenance/license riêng đủ rõ để nhập nguyên các file đó.
Đã viết driver ESP-IDF mới từ Nordic Product Specification cho probe, dump thanh
ghi, quét RPD126 kênh RX-only và theo dõi kênh. RPD là tỷ lệ vượt ngưỡng, không
phải số đo RSSI. Không đánh dấu các chế độ phát/jammer của port cũ là đã chuyển.
Chưa thử module thực. Xingzhi CE4/CS21, shared SPI47/41/48 theo sơ đồ trong mod.

## Chân RF/IR đã đối chiếu

| Bo | IR RX/TX | CC1101 SCK / MISO / MOSI / CS / GDO0 | Nguồn thông tin chân |
| --- | --- | --- | --- |
| Xingzhi Cube S3 | 3 / 12 | 47 / 41 / 48 / 2 / 1 | Bản mod: `boards/xingzhi-cube-s3/pins_arduino.h` |
| CYD-2432S028 | 27 / 22 | 18 / 19 / 23 / 27 / 22 | Bruce 1.17: `boards/CYD-2432S028/interface.cpp` |
| ESP32 OLED generic | Chưa có sơ đồ duy nhất | Chưa có sơ đồ duy nhất | Không tự gán chân xung đột OLED |

CYD dùng chung GPIO22/27 cho các phụ kiện: phải dùng đúng loại phụ kiện/cách nối
của profile, không coi hai cổng đó là hai bus độc lập. Các driver mới giải phóng
ngắt/GDO khi dừng. Chưa kiểm tra các kết nối trên thiết bị thật.

Nguồn đặc tả:
- TI CC1101 datasheet: https://www.ti.com/lit/ds/symlink/cc1101.pdf
- ESP-IDF RMT: https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32/api-reference/peripherals/rmt.html
- ESP-IDF WiFi/BLE API của phiên bản SDK đã pin trong `platformio.ini`.

## Cập nhật N16R8 / UI

Đã bật ESP-IDF PSRAM Octal, flash16MB và CPU240MHz. Menu dùng chữ native-size có coverage; icon1-bit; menu34px không có nhãn phụ, chuyển màn220ms có cache, focus110ms, viền bo góc cố định. Nút trái/phải giữ300ms rồi lặp200ms; OK giữ500ms để Back. Thông tin máy cuộn với số đo heap riêng và PSRAM có điều kiện. Pin lấy mẫu trước khi khởi động WiFi, giữ mẫu gần nhất khi ADC2 bận và thử lại.

BW16 có đa chọn, lọc băng tần, auth/key, lệnh deauth/flood/beacon/portal, gửi lại và lựa chọn chạy nền; phụ thuộc firmware companion, chưa có kết quả phần cứng. Naoya có bàn phím/API key/model/chat, Telex cơ bản và HTTPS xác minh chứng chỉ. USB MSC xuất toàn bộ SD qua cổng native S3, unmount VFS trước khi đưa thẻ cho host; không xuất SPIFFS. Chưa khẳng định tương đương toàn bộ menu Bruce/mod.
