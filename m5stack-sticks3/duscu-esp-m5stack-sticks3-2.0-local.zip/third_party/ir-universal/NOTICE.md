# Universal IR command measurements

Data from Lucaslhm/Flipper-IRDB, pinned to
`d126fb1b6f1e114c52b4a8c19839ea65e3a9c24d`.
https://github.com/Lucaslhm/Flipper-IRDB

License: **CC0-1.0**, retained in `LICENSE`.
Sources and hashes are in `provenance.json`; the original captures are retained
under `../tv-power/` and accompany firmware packages.

555 distinct command/waveform combinations: Power87, CH+77, CH-76, VOL+81,
VOL-82, Mute81 and Input/Source71. A waveform shared by multiple brands keeps
all contributing brand labels. These counts describe measurements, not tested
remote compatibility or the number of supported physical remote models.

Duscu changes: normalize button labels, expand supported parsed protocol
parameters with independently written encoders, and deduplicate within each
command by carrier plus timing rounded50us. No upstream executable code is
included. Editable data is `codes.json`; the generated header contains only
measurement arrays and descriptors.
