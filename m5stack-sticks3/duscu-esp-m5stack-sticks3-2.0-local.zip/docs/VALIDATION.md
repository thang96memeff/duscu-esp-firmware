# Kiểm tra hiện tại — M5StickS3 / MP3 / Rainbow

M5StickS3 N8R8 build/link thành công với SDK5.5.1 và PlatformIO55.03.34; phiên bản hiện tại gồm PM1 pin/sạc/nguồn, ST7789P3, module ngoài, nativeUSB console/MSC, giải mãMP3/phátI2S và chỉnh Rainbow1–30giây. Log: `dist/m5stack-sticks3/build.log` sau khi xuất gói. RAM tĩnh90,632byte; app báo2,556,519byte trong lần link này, dưới phân vùng3MiB. Không khẳng định đã thử bo thật.

Kiểm thử mới qua: MP3 ASan/UBSan (sine44100stereo/22050mono/8000MPEG2.5, ID3, shortreads17byte, EOF/cancel/readerror,500 dữ liệu lỗi, mix/volume bounds); Rainbow vào chỉnh/tăng giảm/chốt/hủy, toàn bộ1..30; SPI lease với đúng hợp đồng IDF5.5; M5 pin/màn/PM1/nút.11 Python tests qua, C++ grammar không lỗi.7 source units cấu hình Xingzhi qua kiểm tra kiểu SDK bằng `-fsyntax-only`; không tạo object/link/export Xingzhi.

Xingzhi đang ngưng build theo yêu cầu chủ dự án. Merged Xingzhi hiện tại vẫn bản14:49UTC, chưa chứa sửa lỗi SPI/GIF/MP3/Rainbow mới. Lỗi radio đã xác định: IDF từ chối acquire_bus với timeout hữu hạn5ms; mã mới dùng portMAX_DELAY theoSDK. Chưa nhận được lần test phần cứng lại sau bản sửa.

Các mục bên dưới là lịch sử; các câu “chưa build” ở lịch sử không mô tả gói M5 hiện tại.

# Lịch sử: IR bổ sung: hai vùng / universal / nhiễu — CHƯA BUILD

- Menu TV-B-Gone NA137/EU138, giữ270 dạng sóng khác nhau trong bộ dữ liệu vùng; bản dữ liệu Adafruit đã pin, CC BY-SA3.0 riêng.
- Universal Remote:555 tổ hợp lệnh/dạng sóng CC0; Power87, CH+77, CH-76, VOL+81, VOL-82, Mute81, Input71. Mỗi nhóm đều có dữ liệu, không phải menu giả.
- Một host executable mới chạy ASan/UBSan: đọc toàn bộ275 bản ghi theo vùng, waveform đầu so với số liệu gốc, phát hiện sóng không modulation/xung dài, bảo toàn tổng duration khi chia RMT, thử2000 resource lỗi/cắt ngắn và giới hạn quét tần số nhiễu.
-11 Python tests qua, gồm chuẩn hóa tên CH+/CH-/VOL, hash các nguồn dữ liệu, không trùng lệnh, và tái tạo hai bộ dữ liệu hoàn toàn offline.
- Kiểm tra kiểu SDK bằng -fsyntax-only qua cho main, ir_power, ir_module, regional_database, services, interface, settings_module. Không tạo object/link/build firmware.
- CMake đã khai báo resource tách riêng với tên linker rõ ràng; bước nhúng/link thực tế cần lần build được chủ dự án cho phép tiếp theo. Công cụ export kiểm tra hash resource, từ chối gói cũ thiếu resource.
- Chưa thử phát IR, hiệu quả nhiễu, bo thật, độ trễ nút hay dung lượng BIN mới. Không làm thêm preview. Bản dist hiện có không chứa các bổ sung này.

# Kiểm tra đợt sửa mới — chưa build firmware

Theo yêu cầu chủ dự án, chỉ chạy host test và kiểm tra kiểu C++ với SDK bằng `-fsyntax-only`. Không configure lại CMake, không tạo object/link firmware, không xuất BIN. Những log build ở phần lịch sử bên dưới không xác nhận đợt sửa hiện tại.

- 9 chương trình test host qua; parser IR/SubGHz và bộ giải mã GIF chạy AddressSanitizer/UndefinedBehaviorSanitizer.
- GIF: từng pixel RGB565 so với Pillow; disposal2/3, interlace, LZW12bit, bảng màu cục bộ, trong suốt, delay, lặp hữu hạn/vô hạn, resize, mở lại tệp mỗi khung và1000 tệp biến dạng/cắt ngắn. Trình xem vẫn chưa thử trên SD/bo thật.
- Remote: nhiều nút IR, NEC/SIRC wire order, raw .ir/.sub round trip, số tràn, giao thức không hỗ trợ, hủy đọc; tệp lỗi giữ remote cũ.
- nRF:126 kênh gồm125, mức RPD không vượt100, decay/EMA, counter không tràn. Chưa đo RF trên phần cứng.
- BLE:7 dạng quảng bá đều≤31byte, AD fields hợp lệ và parser nhận iBeacon/Eddystone. Không xác nhận tương tác với thiết bị ngoài.
- Dữ liệu TV:87 dạng sóng khác nhau; hash299 tệp CC0 đã pin,93 nhãn hãng sau giữ alias;7 Python tests qua.

# Trạng thái kiểm tra — N16R8

Ngày2026-11-15, nhánh ESP-IDF local; chưa flash bo hoặc công bố bản phát hành.

## Đã kiểm tra

- Build/link `xingzhi-cube` với ESP-IDF5.5.1, flash16MB, CPU240MHz, PSRAM Octal80MHz, app partition3MiB. Kconfig thực đã kiểm tra, không chỉ dựa nhãn board PlatformIO. Kết quả và kích thước chính xác theo `dist/xingzhi-cube/manifest.json` cùng log.
- Host C++: model/timer/touch/hit-test; packed1/2/4-bit slide ở mọi độ lệch và chiều; dirty bounds; carousel đổi hướng; lặp nút giữ và thả không phát click thừa; geometry Home ở128×128,240×240,320×240,480×320.
- Host icon:1-bit, wave frames và Settings hai frame khác nhau, cache native40/48/56px. Bộ font coverage và sprite tái tạo đúng từ đầu vào đã pin.
- Host BLE: cấu trúc AD/TLV và giới hạn31byte, đọc tên bằng parser độc lập. Chưa đo gói phát trên không hay thông báo từ Windows.
- Host IR: split xung dài không cắt ngắn thời gian; NEC byte order/inverse; SIRC ba frame45ms; hash nguồn CC0 và giới hạn bộ mã87 mục.
- Telex cơ bản: tiếng/Việt/đường/chào. Bàn phím không thay thế một bộ gõ tiếng Việt đầy đủ.
- File viewer: AddressSanitizer/UndefinedBehaviorSanitizer qua với cấu hình miniz aligned/32-bit như target: CRLF/UTF-8, file dài/rỗng, PNG/BMP nhiều định dạng, malformed images, hủy đọc. Host x86 fast path của miniz trước đó báo unaligned accesses; patch chỉ cho phép chọn cấu hình portable rõ ràng, không thay đổi mặc định target.
- Python unit tests:7 kiểm tra nguồn/font/IR data. Source comparison không thấy overlap theo quy tắc công cụ; không phải chứng nhận pháp lý.
- Preview: Node navigation/profiles/frame/reduced-motion; Chromium143 kiểm tra file HTML chép riêng, canvas, animation, menu, ba profile và fallback khi tắt JavaScript. Báo cáo kèm SHA256 ở `preview-browser-check.json`.
- Gói binary local giữ license, notice, dependency lock, dữ liệu TV CC0 và các PEM certificate source theo MPL2.0. Không chứa source ứng dụng đóng.

## Chưa có bằng chứng phần cứng

Chưa đo FPS/độ trễ trên panel hoặc so với Bruce mod. Chưa xác nhận chip PSRAM thực được nhận8MB, ADC17/divider2:1/charge38, pin%, GPIO, radio/IR, WiFi/BLE/TLS đồng thời, JPEG ROM, SD lỗi/tháo thẻ, hoặc USB host read/write/eject trên bo. `PERF`, `BATTERY` và màn Thông tin máy phục vụ kiểm tra này. Build thành công không chứng minh những phần trên hoạt động.

USB MSC nhường SD độc quyền cho host, không autoformat, không xuất SPIFFS. Cần cổng USB native S3 nối GPIO19/20; eject trên PC trước khi dừng. BW16 phụ thuộc firmware companion đang có, không đi kèm firmware BW16 thay thế. Các mục Bruce/mod chưa được triển khai ghi trong `FEATURE_PARITY.md`.

CYD/OLED chưa build lại bản tích hợp hiện tại; không dùng kết quả cũ để khẳng định chúng đã qua. Preview các cỡ màn là kiểm tra UI, không kiểm tra LCD driver hay giới hạn heap trên những board đó.

Phân vùng N16R8 chuyển SPIFFS từ0x210000 sang0x310000. Sao lưu tệp trước khi nâng từ bản4MB. Ảnh merged tại0x0 ghi padding qua NVS/PHY; dùng hướng dẫn file rời để giữ NVS tương thích. Firmware không tự format hay di chuyển dữ liệu cũ.

## Lượt cập nhật Settings/rainbow/game

Host tests mới qua: màu và compositeRGB565, vùng tile rainbow bao phủ thay đổi, rotation/touch round-trip, game random-state bounds. Audit71 tệp không phát hiện overlap cần xem lại; Tetris có xác nhận riêng, không coi audit là chứng nhận quyền tác giả. Xem build.log và manifest trong dist/xingzhi-cube cho binary cuối. Rainbow/wallpaper/rotation/input runtime/sleep/USB vẫn chưa có phép thử board thật; preview chỉ mô phỏng thiết kế.
