## Current main menu — Orbit (2026-11-18)

The owner sketch replaces the horizontal3-icon carousel. See [HOME_ORBIT.md](HOME_ORBIT.md) for current layout,135px threshold,fonts and motion. Normal UI uses the owner Unifont resources (Duscu Mono); older Noto/carousel descriptions below are historical. Xingzhi test-build status is recorded in docs/development/CHECKPOINT.md. Preview assets have not been regenerated.

# DUSCU-IDF:1.0 — UI và input

Sau cập nhật luồng cốt lõi, RF/IR ưu tiên Thu → Lưu → Phát, WiFi/BLE gom công cụ phụ vào Nâng cao/Cài đặt; xem [CORE_WORKFLOWS.md](CORE_WORKFLOWS.md). Bàn phím màn ngắn/hẹp dùng carousel5phím;240×240 vẫn dùng lưới.

Rainbow: chọn dòng thời gian trong Settings → Màu sắc, OK để chỉnh ngay tại dòng đó. Prev/Next tăng/giảm từng1giây, giới hạn1–30giây. Giá trị xem trước trong RAM; OK lần hai mới lưu, rồi Prev/Next tiếp tục di chuyển menu. Back hủy về giá trị cũ. Không mở bàn phím hoặc đổi sang màn hình riêng khi chỉnh.

Files có trình phátMP3 và thao tác trên hai nút M5StickS3; xem [AUDIO.md](AUDIO.md), [M5STICKS3.md](M5STICKS3.md).

Giao diện đen/trắng với viền bo góc luôn hiển thị trên TFT. Nhãn phiên bản nằm trong khung bo góc riêng, hạ thấp hơn trước; không có đường phân tách dưới status bar. Home có ba app, chỉ app giữa có khung và tên lớn. Không có mô tả nhỏ dưới title. Menu trong dùng hàng34px với tên18px và không có nhãn phụ, hiển thị được5 mục trên240×240. OLED128×64 dùng bố cục riêng.

## Render

- Icon giữ1-bit, SVG chỉnh sửa trong `assets/icons/`. Cache native40/48/56/64px tránh phóng bitmap nhỏ khi đứng yên. Icon giữa trên240×240 là64px, hai bên40px; khung chọn có viền2px. Settings có hai frame0/45°, sóng WiFi/RF/IR/nRF chạy1→2→3→tắt,180ms/bước. Naoya/BW16 theo phần chủ dự án xác nhận quyền sở hữu, có provenance riêng.
- Chữ raster trực tiếp ở12/18/24/36px từ Noto Sans, coverage4-bit được lượng tử thành4 mức trên TFT để làm mịn cạnh. Không phóng to pixel của font12px. Font vẫn theo OFL; icon không chuyển sang grayscale. OLED xuất1-bit.
- Framebuffer TFT2-bit:240×240 dùng14,400byte/buffer. Bốn buffer dùng57,600byte, gồm frame đang vẽ, frame đã truyền, nền cũ và đích chuyển tiếp. N16R8 cho phép malloc lớn đi vào PSRAM. SSD1306 giữ surface1-bit.
- So sánh byte thật để tìm vùng thay đổi; không truyền khi frame không đổi. TFT SPI40MHz, hai DMA buffer5120byte, queue hai transaction. Không có đọc SD hay parse ảnh trong renderer.
- Carousel160ms và đảo chiều từ vị trí hiện tại; focus danh sách110ms. Chuyển app và menu→chi tiết trượt từ phải220ms, Back ngược chiều, easing cubic-out. Frame đích được cache, không vẽ lại toàn bộ nội dung ở từng bước slide. Viền ngoài vẽ lại sau khi ghép để đứng yên.
- Đường bo góc chỉ duyệt các cạnh và góc khi vẽ outline, tránh quét toàn màn hình để vẽ một viền.
- Lịch animation16ms và poll input2ms là mục tiêu lập lịch. Chưa có số FPS đo trên board hay so sánh với Bruce mod trên cùng phần cứng.

## Input và bàn phím

Nút Prev/Next phát sự kiện sau debounce25ms; giữ300ms bắt đầu lặp200ms/lần. Thả nút không tạo thêm click. Select ngắn kích hoạt; giữ500ms Back. CYD một nút có phân biệt ngắn/giữ, ngoài tap/vuốt XPT2046. Drawing và hit test dùng chung `ListLayout`.

Bàn phím trên thiết bị có chữ thường/hoa/ký hiệu, Del, Space, Aa và OK. Aa chuyển thêm chế độ Vi/Telex khi ô không phải mật khẩu. Telex cơ bản do dự án tự viết, không nhập `core/telex` từ Bruce. Back hủy nhập. WiFi hỗ trợ chọn AP hoặc SSID ẩn; Naoya nhập key/model/câu hỏi trực tiếp. Key chỉ lưu NVS khi chọn Lưu cấu hình AI.

## Pin và thông tin máy

Xingzhi GPIO17 ADC, GPIO38 báo sạc, divider2:1 theo cấu hình phần cứng cần kiểm tra thực tế. Đọc pin đầu tiên trước khi khởi động WiFi; calibration SDK, lấy các mẫu thành công và EMA. Khi ADC2 bận giữ mẫu tối đa30s, thử lại200ms. Không có số đo hợp lệ thì hiện `--%`, không điền phần trăm giả. Đây là ước lượng Li-ion theo điện áp, không phải fuel gauge.

Thông tin máy cuộn bằng Prev/Next: tên board, phiên bản, flash/partition app, dung lượng tệp SPIFFS, SD đã mount, RAM heap nội bộ, PSRAM khi profile có cấu hình, điện áp pin. Flash/SD được lấy trong task nền; không quét FAT free-space trong vòng vẽ. RAM free không phải dung lượng flash hay tổng PSRAM. Nếu PSRAM bật nhưng chip chưa được nhận diện, màn hình ghi rõ.

## Xem trước và kiểm tra trên bo

`preview/index.html` và `preview/xingzhi-cube.html` là file tự chứa. Canvas chỉ bật sau khi khởi tạo thành công; SVG tĩnh còn hiện khi JavaScript bị chặn. Trang là mô phỏng UI, không thực thi WiFi/radio/AI/USB. Pin mẫu luôn là `--%`.

Tái tạo bằng `tools/build_preview.py`; kiểm tra bằng `tests/preview_test.js` và `tests/preview_browser_test.js`. Đo bo thật bằng `PERF RESET`, thao tác chuyển menu, rồi `PERF` để lấy FPS/thời gian render thật. `BATTERY` cung cấp điện áp và trạng thái ADC. Không suy ra tốc độ board từ tốc độ mô phỏng browser.

## Cập nhật màu, panel và game

Yêu cầu màu mới thay thế giới hạn chỉ đen/trắng trước đó. Mặc định vẫn trắng; palette tùy chọn và rainbow đổi màu chữ/viền. Rainbow dùng các tile16×16 có nội dung, gộp vùng liền nhau trước khi truyền để tránh full-frame mỗi nhịp đổi màu. Hình nền crop về kích thước hiện tại, cache RGB565; render chỉ đọc cache.

Panel geometry và touch cập nhật theo rotation/kích thước. Preset cần đúng controller, vùng GRAM, offset và dây thực; không phải cam kết mọi màn đều chạy. OLED vẫn1-bit, màu không áp dụng lên phần cứng đơn sắc. Settings/Game là AppModule riêng. Game Tetris port theo quyền chủ dự án, provenance tại game-provenance.json. Preview chỉ mô phỏng danh mục/màu/nền mẫu; không chạy game hay cấu hình phần cứng.

## Sửa nguồn chờ build

Chọn hình nền mở app Files ở chế độ chọn ảnh; root chỉ có SPIFFS/SD, danh sách lọc PNG/BMP/JPEG và thư mục. OK trên ảnh preview đặt nền rồi trả về đúng trang Settings; Back hủy không đổi hình nền. Giữ nút Back500ms; một nút dùng dưới250ms để Next,250–499ms để Select,500ms để Back (tính sau debounce25ms).

Tối ưu RGB: không có wallpaper dùng palette4 mức chuẩn bị một lần mỗi frame; có wallpaper dùng LUT theo kênh, tránh phép chia/composite theo từng pixel. Cache cùng kích thước truy cập trực tiếp. Rainbow tạm giữ màu khi carousel/submenu/focus chuyển động hoặc đang chơi để ưu tiên FPS; chưa có phép đo FPS trên bo xác nhận mức cải thiện. Các sửa này chưa được build theo yêu cầu chủ dự án.
