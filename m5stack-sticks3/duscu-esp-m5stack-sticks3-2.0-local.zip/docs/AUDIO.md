# MP3 trong Files

Mở tệp `.mp3` trên SD hoặc SPIFFS. Xingzhi Cube phát qua I2S BCLK15/WS16/DOUT7; M5StickS3 phát qua ES8311 và loa tích hợp. Các board chưa cấu hình loa báo rõ thay vì giả vờ đang phát.

- OK: phát/tạm dừng; khi bài đã kết thúc, OK phát lại.
- Prev/Next: âm lượng ±5%, giới hạn0–100%.
- Tổ hợp hai nút: chuyển Prev/Next sang tua ±10s; tổ hợp lần nữa trở lại âm lượng.
- Back: dừng và quay lại danh sách tệp.
- M5StickS3: B một lần tương ứng Next, B hai lần Previous, A+B là tổ hợp.

Giao diện hiển thị tên/ID3 title, artist nếu có, thời gian đã phát, thời lượng ước lượng, tiến trình, âm lượng và Hz/kbps. Thời gian đã phát tính từ mẫu PCM; thời lượng và vị trí tua dùng bitrate, vì vậy chỉ gần đúng với VBR. Stereo được trộn mono và gửi cả hai slot I2S cho loa đơn. Hỗ trợ MPEG LayerIII,8–48kHz, mono/stereo, kể cả MPEG2/2.5.

Đọc theo khối4KiB; không nạp cả bài vào RAM. File đóng trước khi nhả quyền Storage, nên USB MSC có thể lấy SD mà không giữ lại handle tệp đang mở. Decoder, PCM và task stack32KiB được giải phóng khi dừng. Pause/Back không chạy giải mã trong UI thread. M5PM1 quản lý codec/amp, không bật loa khi bộ thu IR đang hoạt động; thoát Files dừng phát trước khi chuyển ứng dụng.

Decoder [minimp3](https://github.com/lieff/minimp3) được pin và giữ nguồn/licenseCC0 tại `third_party/minimp3`. Trình đọc luồng, điều khiển phát, metadata và I2S là mã riêng của dự án. Thông số ES8311/StickS3 tham khảo tài liệu và cấu hình chính thức M5Stack; Xingzhi dùng chân phần cứng của cấu hình Cube1.54.

Kiểm thử dùng sóng sin tự sinh bằng dependency test-onlylameenc; không thêm dependency này vào firmware:

```sh
python tests/make_mp3_fixtures.py .cache/mp3-fixtures
c++ -std=c++17 -O1 -g -fsanitize=address,undefined -Isrc -Ithird_party/minimp3 tests/mp3_test.cpp src/modules/audio/mp3_stream.cpp -o /tmp/duscu-mp3-test
/tmp/duscu-mp3-test .cache/mp3-fixtures
```

Chưa đo âm thanh, thời gian đáp ứng hoặc FPS trên thiết bị thật. Xingzhi đang tạm ngưng build theo yêu cầu chủ dự án; thay đổi MP3 ở source sẽ vào BIN sau khi được yêu cầu build lại.
